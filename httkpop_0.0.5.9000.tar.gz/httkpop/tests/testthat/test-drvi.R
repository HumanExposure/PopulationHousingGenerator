library(httkpop)
library(data.table)
context("compare direct-resampling and virtual-individuals methods")

TeachingDemos::char2seed("Caroline Ring")
pop_dr <- httkpop::httkpop_generate(method="d",
                                    nsamp=1000)
pop_vi <- httkpop::httkpop_generate(method="v",
                                    nsamp=1000)
p_cutoff <- 0.01

test_that("dr and vi methods give the same proportions of gender and race", {
  gr_all <- expand.grid(g=c("Male", "Female"), 
                        r=c("Non-Hispanic Black",
                            "Non-Hispanic White",
                            "Mexican American",
                            "Other Hispanic",
                            "Other"))

  expect_true(prop.test(c(pop_dr[, sum(gender=="Male")], 
                          pop_vi[, sum(gender=="Male")]), 
                        n=c(1000,1000))$p.value>p_cutoff)
  
  expect_true(all(sapply(c("Non-Hispanic Black",
                           "Non-Hispanic White",
                           "Mexican American",
                           "Other Hispanic",
                           "Other"),
                         function(r) prop.test(c(pop_dr[, sum(reth==r)],
                                                 pop_vi[, sum(reth==r)]),
                                               n=c(1000,1000))$p.value>p_cutoff)))
  
  expect_true(all(mapply(FUN=function(g,r) {
    prop.test(c(pop_dr[, sum(reth==r & gender==g)],
                pop_vi[, sum(reth==r & gender==g)]),
              n=c(1000,1000))$p.value>p_cutoff
  }, 
  g=gr_all$g, 
  r=gr_all$r)))
})

test_that("dr and vi methods give approximately the same proportions of weight classes",{
  expect_true(all(sapply(c("Underweight",
                           "Normal",
                           "Overweight",
                           "Obese"),
                         function(wc) prop.test(c(pop_dr[, sum(weight_class==wc)],
                                     pop_vi[, sum(weight_class==wc)]),
                                   n=c(1000,1000))$p.value>p_cutoff)))
})

test_that("dr and vi methods yield approximately the same age distributions", {
            expect_true(wilcox.test(pop_dr[, age_months],
                                    pop_vi[, age_months])$p.value>p_cutoff)
            expect_true(wilcox.test(pop_dr[, age_years],
                                    pop_vi[, age_years])$p.value>p_cutoff)
            
          })

test_that("dr and vi methods yield similar distributions of physiological quantities", {
  expect_true(wilcox.test(pop_dr[, height],
                          pop_vi[, height])$p.value>p_cutoff)
  expect_true(wilcox.test(pop_dr[, weight_adj],
                          pop_vi[, weight_adj])$p.value>p_cutoff)
  expect_true(all(sapply(grep(x=names(pop_dr),
                              pattern="_mass$",
                              value=TRUE,
                              perl=TRUE),
                         function(q) wilcox.test(unlist(pop_dr[, q, with=FALSE]),
                                                 unlist(pop_vi[, q, with=FALSE]))$p.value>p_cutoff)))
  expect_true(all(sapply(grep(x=names(pop_dr),
                              pattern="_flow$",
                              value=TRUE,
                              perl=TRUE),
                         function(q) wilcox.test(unlist(pop_dr[, q, with=FALSE]),
                                                 unlist(pop_vi[, q, with=FALSE]))$p.value>p_cutoff)))
  expect_true(wilcox.test(pop_dr[, CO],
                          pop_vi[, CO])$p.value>p_cutoff)
  expect_true(wilcox.test(pop_dr[, hematocrit],
                          pop_vi[, hematocrit])$p.value>p_cutoff)
  expect_true(wilcox.test(pop_dr[, serum_creat],
                          pop_vi[, serum_creat])$p.value>p_cutoff)
  expect_true(wilcox.test(pop_dr[, million.cells.per.gliver],
                          pop_vi[, million.cells.per.gliver])$p.value>p_cutoff)
  expect_true(wilcox.test(pop_dr[, gfr_est],
                          pop_vi[, gfr_est])$p.value>p_cutoff)
  
})
